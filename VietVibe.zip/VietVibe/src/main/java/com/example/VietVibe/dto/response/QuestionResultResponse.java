package com.example.VietVibe.dto.response;

import lombok.Data;

@Data
public class GameResultResponse {
    private Long questionId;
    private boolean correct;
}
