package com.example.VietVibe.dto.response;

import java.util.List;

import lombok.Data;

@Data
public class GameResultResponse {
    private Long gameId;
    private int totalQuestions;
    private int correctCount;
    private double accuracy;
    private int score;

    private List<QuestionResultResponse> details;
}
