package com.example.VietVibe.dto.request;

import java.util.List;

import lombok.Data;

@Data
public class GameSubmitRequest {
    private List<QuestionAnswerRequest> answers;

    // optional
    private Integer timeSpent; // giây
}
